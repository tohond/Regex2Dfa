/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AutomataRegexThompson_LanguageToFDA.EpsilonNFA_DFA;

import AutomataRegexThompson_LanguageToFDA.RegexToEpsilonNFA.Estado;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

/**
 *
 * @author Administrador
 */
public class DFA {
    LinkedHashSet<Estado> nuevosEstados = new LinkedHashSet<>();
    Estado estadoInicial;
    Estado estadoFinal;
    public ArrayList<String> alfabeto; 
    
    public Estado getEstadoInicial() {
        return estadoInicial;
    }

    public Estado getEstadoFinal() {
        return estadoFinal;
    }
    
    public DFA (FuncionDeTransicion ftInicial){
        
    }
}
